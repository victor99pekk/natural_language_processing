
# Instructions to run program
Instructions on commands to run Deep averaging network with glove-initialized word2vec embeddings, or randomly initialized embeddings.

## Glove-embedding
```py
python run_pre-trained_embedding.py --model DAN
```

## randomly initialized- embedding
```py
python run_randomly-initialized_embedding.py --model DAN
```